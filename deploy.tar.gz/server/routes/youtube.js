import express from 'express';
// Use yt-dlp service which is more reliable than ytdl-core
import { getVideoInfo, createVideoStream, createFastVideoStream, validateVideo, getStreamFormat, getDirectUrl } from '../services/ytdlpService.js';
import { extractVideoId, sanitizeUrl, isAllowedPlatform } from '../utils/urlParser.js';
import { streamLimiter } from '../middleware/rateLimit.js';

const router = express.Router();

/**
 * Middleware to validate and sanitize URL inputs
 */
function validateUrlInput(req, res, next) {
    const url = req.query.url || req.query.v;
    
    if (url) {
        const sanitized = sanitizeUrl(url);
        if (!sanitized) {
            return res.status(400).json({
                error: 'Invalid URL format',
                code: 'INVALID_URL'
            });
        }
        
        // For full URLs, validate platform
        if (sanitized.includes('://') && !isAllowedPlatform(sanitized)) {
            return res.status(400).json({
                error: 'URL not from supported video platform',
                code: 'UNSUPPORTED_PLATFORM'
            });
        }
        
        // Store sanitized URL for downstream use
        req.sanitizedUrl = sanitized;
    }
    
    next();
}

/**
 * GET /api/youtube/validate?url=...
 * Validate a YouTube URL and check if it can be streamed
 */
router.get('/validate', validateUrlInput, async (req, res, next) => {
    try {
        const url = req.sanitizedUrl || req.query.url;
        if (!url) {
            return res.status(400).json({
                valid: false,
                error: 'URL parameter required',
                code: 'MISSING_URL'
            });
        }

        const result = await validateVideo(url);
        res.json(result);
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/youtube/info?url=...
 * Get detailed video metadata
 */
router.get('/info', validateUrlInput, async (req, res, next) => {
    try {
        const url = req.sanitizedUrl || req.query.url;
        if (!url) {
            return res.status(400).json({ error: 'URL parameter required' });
        }

        const info = await getVideoInfo(url);
        res.json(info);
    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/youtube/stream?v=VIDEO_ID&q=quality
 * GET /api/youtube/stream?url=FULL_URL&q=quality
 * Stream video content - main endpoint for video texture
 * Supports YouTube, Vimeo, Dailymotion, and other yt-dlp supported platforms
 */
router.get('/stream', validateUrlInput, streamLimiter, async (req, res, next) => {
    try {
        // Use sanitized URL from middleware or fall back to query params
        let videoIdOrUrl = req.sanitizedUrl || req.query.url || req.query.v;
        const quality = req.query.q || 'auto';

        // If v= parameter looks like a YouTube ID, use it directly
        // Otherwise, try to extract from url parameter or use as-is
        if (req.query.v && !req.query.v.includes('://')) {
            videoIdOrUrl = req.query.v;
        } else if (req.query.url) {
            videoIdOrUrl = req.query.url;
        }

        if (!videoIdOrUrl) {
            return res.status(400).json({
                error: 'Video URL required. Use ?url=VIDEO_URL or ?v=VIDEO_ID',
                code: 'MISSING_VIDEO_URL'
            });
        }

        console.log(`[STREAM] ${videoIdOrUrl}, quality: ${quality}`);

        // TRY FAST STREAM FIRST (uses cached direct URL - INSTANT!)
        try {
            const fastStream = await createFastVideoStream(videoIdOrUrl, quality);
            
            // Set response headers
            res.setHeader('Content-Type', fastStream.contentType || 'video/mp4');
            res.setHeader('Accept-Ranges', 'bytes');
            res.setHeader('Cache-Control', 'no-cache');
            if (fastStream.contentLength) {
                res.setHeader('Content-Length', fastStream.contentLength);
            } else {
                res.setHeader('Transfer-Encoding', 'chunked');
            }

            let bytesSent = 0;
            fastStream.stream.on('data', (chunk) => {
                bytesSent += chunk.length;
            });

            fastStream.stream.on('error', (error) => {
                console.error(`[STREAM ERROR] ${videoIdOrUrl}:`, error.message);
                if (!res.headersSent) {
                    res.status(500).json({ error: 'Stream failed', message: error.message });
                } else {
                    res.end();
                }
            });

            // Pipe to response
            fastStream.stream.pipe(res);

            // Clean up on client disconnect
            req.on('close', () => {
                if (fastStream.cleanup) {
                    fastStream.cleanup();
                }
            });
            
            return; // Done!
        } catch (fastStreamError) {
            console.warn(`[STREAM] Fast stream failed, falling back to yt-dlp: ${fastStreamError.message}`);
        }

        // FALLBACK: Use yt-dlp streaming (slower but reliable)
        // Get format info for headers
        let formatInfo;
        try {
            formatInfo = await getStreamFormat(videoIdOrUrl, quality);
        } catch (e) {
            // Format info is optional - Plan C (Invidious) may not provide it
            console.warn(`[STREAM] Format info unavailable for ${videoIdOrUrl}: ${e.message}`);
        }

        // Determine content type - prefer mp4
        const contentType = formatInfo?.container === 'webm' ? 'video/webm' : 'video/mp4';

        // Set response headers for video streaming
        // DON'T set Content-Length - we're streaming and size may vary
        res.setHeader('Content-Type', contentType);
        res.setHeader('Accept-Ranges', 'bytes');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Transfer-Encoding', 'chunked');

        // Create the stream using yt-dlp
        const { stream, process: ytdlpProc } = createVideoStream(videoIdOrUrl, quality);

        let bytesSent = 0;
        let hasStarted = false;

        stream.on('data', (chunk) => {
            if (!hasStarted) {
                hasStarted = true;
            }
            bytesSent += chunk.length;
        });

        stream.on('error', (error) => {
            console.error(`[STREAM ERROR] ${videoIdOrUrl}:`, error.message);
            if (!res.headersSent) {
                res.status(500).json({ error: 'Stream failed', message: error.message });
            } else {
                res.end();
            }
        });

        stream.on('end', () => {
            // Stream completed
        });

        // Pipe to response
        stream.pipe(res);

        // Clean up on client disconnect
        req.on('close', () => {
            if (ytdlpProc && !ytdlpProc.killed) {
                ytdlpProc.kill();
            }
        });

    } catch (error) {
        next(error);
    }
});

/**
 * GET /api/youtube/direct?v=VIDEO_ID&q=quality
 * Get direct video URL that the browser can load directly
 * This avoids proxy overhead but URLs expire after some time
 */
router.get('/direct', validateUrlInput, async (req, res, next) => {
    try {
        const videoId = req.query.v || extractVideoId(req.sanitizedUrl || req.query.url);
        const quality = req.query.q || 'auto';

        if (!videoId) {
            return res.status(400).json({
                error: 'Video ID required',
                code: 'MISSING_VIDEO_ID'
            });
        }

        console.log(`[DIRECT] Getting URL for: ${videoId}`);

        const result = await getDirectUrl(videoId, quality);

        const response = {
            videoId,
            url: result.url,
            format: result.format,
            // URLs typically expire in ~6 hours
            expiresIn: '~6 hours'
        };

        res.json(response);

    } catch (error) {
        console.error(`[DIRECT] Error for ${req.query.v}:`, error.message);
        next(error);
    }
});

/**
 * GET /api/youtube/thumbnail?v=VIDEO_ID
 * Get video thumbnail (redirects to YouTube CDN)
 */
router.get('/thumbnail', (req, res) => {
    const videoId = req.query.v || extractVideoId(req.query.url);
    if (!videoId) {
        return res.status(400).json({ error: 'Video ID required' });
    }

    // Use high quality thumbnail
    const quality = req.query.q || 'mq'; // mq, hq, sd, maxres
    const qualityMap = {
        'mq': 'mqdefault',
        'hq': 'hqdefault',
        'sd': 'sddefault',
        'maxres': 'maxresdefault'
    };

    const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/${qualityMap[quality] || 'mqdefault'}.jpg`;
    res.redirect(thumbnailUrl);
});

/**
 * GET /api/youtube/formats?v=VIDEO_ID
 * Get available formats for a video (for debugging/advanced use)
 */
router.get('/formats', async (req, res, next) => {
    try {
        const videoId = req.query.v || extractVideoId(req.query.url);
        if (!videoId) {
            return res.status(400).json({ error: 'Video ID required' });
        }

        const info = await getVideoInfo(videoId);
        res.json({
            videoId: info.videoId,
            title: info.title,
            availableQualities: info.availableQualities
        });
    } catch (error) {
        next(error);
    }
});

export default router;
